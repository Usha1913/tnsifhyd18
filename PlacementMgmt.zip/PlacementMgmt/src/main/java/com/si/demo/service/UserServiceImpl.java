package com.si.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.si.demo.entity.User;
import com.si.demo.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepository userRepository;

	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);

	}

	@Override
	public void deleteUserById(Long userId) {
		// TODO Auto-generated method stub
		userRepository.deleteById(userId);

	}
@Override
	public List<User> fetchUserList1() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public User fetchUserById1(Long userId) {
		// TODO Auto-generated method stub
		return userRepository.findById(userId).get();

	}

	@Override
	public User updateUser1(Long userId, User user) {
		// TODO Auto-generated method stub
		User userDB= userRepository.findById(userId).get();

	
	 if(Objects.nonNull(user.getUsername()) &&
		       !"".equalsIgnoreCase(user.getUsername())) {
		           userDB.setUsername(user.getUsername());
		       }

		       return userRepository.save(userDB);
		}

	
	

}
