package com.si.demo.service;



import java.util.List;

import com.si.demo.entity.User;

public interface UserService {

	User saveUser(User user);

	void deleteUserById(Long userId);

	List<User> fetchUserList1();

	






	


	
	User updateUser1(Long userId, User user);

	User fetchUserById1(Long userId);




	
	
	
}
