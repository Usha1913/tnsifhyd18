package com.si.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long Userid;
	private String Username;
	private String Userpassword;
	
	
	public User() {
		super();
	}


	public User(long userid, String username, String userpassword) {
		super();
		Userid = userid;
		Username = username;
		Userpassword = userpassword;
	}


	public long getUserid() {
		return Userid;
	}


	public void setUserid(long userid) {
		Userid = userid;
	}


	public String getUsername() {
		return Username;
	}


	public void setUsername(String username) {
		Username = username;
	}


	public String getUserpassword() {
		return Userpassword;
	}


	public void setUserpassword(String userpassword) {
		Userpassword = userpassword;
	}


	@Override
	public String toString() {
		return "User [Userid=" + Userid + ", Username=" + Username + ", Userpassword=" + Userpassword + "]";
	}


	

}
